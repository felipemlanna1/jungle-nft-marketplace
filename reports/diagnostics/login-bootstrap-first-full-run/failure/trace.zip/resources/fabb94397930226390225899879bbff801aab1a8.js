import{r as d,j as s}from"./react-runtime-Dg_oQ7P3.js";import{c,I as n}from"./application-mO1N5waw.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=c("Eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);function u(e){const r=d.useId(),[t,o]=d.useState(!1);return{id:e??r,visible:t,toggle:()=>o(a=>!a)}}function g({label:e,hideLabel:r=!1,id:t,...o}){const{id:a,visible:i,toggle:l}=u(t);return s.jsxs("div",{className:"field password-field",children:[s.jsx("label",{htmlFor:a,className:r?"visually-hidden":void 0,children:e}),s.jsxs("span",{className:"password-input-wrap",children:[s.jsx(n,{...o,id:a,type:i?"text":"password"}),s.jsx("button",{className:"password-toggle",type:"button",onClick:l,"aria-label":`${i?"Ocultar":"Mostrar"} ${e.toLowerCase()}`,"aria-pressed":i,children:i?s.jsx(p,{size:17,"aria-hidden":"true"}):s.jsx("img",{src:"/figma/login/imgHide.svg",alt:""})})]})]})}export{g as P};
